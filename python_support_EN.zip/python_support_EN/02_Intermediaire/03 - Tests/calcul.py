

def moyenne(*args):
    return sum(args) / len(args)
