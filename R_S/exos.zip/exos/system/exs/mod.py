
if __name__ == '__main__':
    print('Module exécuté')
else:
    print('Module importé:', __name__)
