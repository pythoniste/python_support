import requests

request.get("http://127.0.0.1/mensualite/200000/0.0475/240")

print(request.json())

